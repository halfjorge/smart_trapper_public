use anyhow::{Context, Result};
use image::{ImageBuffer, Rgba};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug, Deserialize)]
struct JobFile {
    docName: String,
    widthPx: u32,
    heightPx: u32,
    resolution: f64,
    keyLayerName: String,
    paperLayerName: String,
    colors: Vec<ColorMeta>, // bottom->top
    files: Vec<FileMeta>,   // includes KEY + COLOR entries
}

#[derive(Debug, Deserialize)]
struct ColorMeta {
    name: String,
    blendMode: String,
    opacity: f64,
    fillOpacity: f64,
}

#[derive(Debug, Deserialize, Clone)]
struct FileMeta {
    kind: String,     // "KEY" or "COLOR"
    name: String,
    blendMode: String,
    opacity: f64,
    fillOpacity: f64,
    png: String,      // relative path "masks/..png"
}

#[derive(Debug, Serialize)]
struct TrapSpec {
    source: String,
    target: String,
    png: String,      // relative "traps/..png"
}

#[derive(Debug, Serialize)]
struct TrapsOut {
    traps: Vec<TrapSpec>,
}

fn sanitize(s: &str) -> String {
    s.trim()
        .chars()
        .map(|ch| match ch {
            '/' | '\\' | ':' | '*' | '?' | '"' | '<' | '>' | '|' => '_',
            _ => ch,
        })
        .collect()
}

fn read_mask_rgba(path: &Path) -> Result<(u32, u32, Vec<u8>)> {
    let img = image::open(path)
        .with_context(|| format!("open png: {}", path.display()))?
        .to_rgba8();
    let (w, h) = img.dimensions();
    Ok((w, h, img.into_raw()))
}

fn alpha_to_bit(w: u32, h: u32, rgba: &[u8]) -> Vec<u8> {
    let mut out = vec![0u8; (w * h) as usize];
    for i in 0..(w * h) as usize {
        let a = rgba[i * 4 + 3];
        out[i] = if a > 0 { 1 } else { 0 };
    }
    out
}

fn dilate_square(src: &[u8], w: u32, h: u32, r: i32) -> Vec<u8> {
    if r <= 0 {
        return src.to_vec();
    }
    let mut out = vec![0u8; (w * h) as usize];
    let w_i = w as i32;
    let h_i = h as i32;

    for y in 0..h_i {
        for x in 0..w_i {
            let mut on = 0u8;
            'neigh: for yy in (y - r)..=(y + r) {
                if yy < 0 || yy >= h_i { continue; }
                for xx in (x - r)..=(x + r) {
                    if xx < 0 || xx >= w_i { continue; }
                    let idx = (yy as u32 * w + xx as u32) as usize;
                    if src[idx] != 0 {
                        on = 1;
                        break 'neigh;
                    }
                }
            }
            out[(y as u32 * w + x as u32) as usize] = on;
        }
    }
    out
}

fn and(a: &[u8], b: &[u8]) -> Vec<u8> {
    a.iter()
        .zip(b.iter())
        .map(|(&x, &y)| if x != 0 && y != 0 { 1 } else { 0 })
        .collect()
}

fn and_not(a: &[u8], b: &[u8]) -> Vec<u8> {
    // a & !b
    a.iter()
        .zip(b.iter())
        .map(|(&x, &y)| if x != 0 && y == 0 { 1 } else { 0 })
        .collect()
}

fn write_trap_png(path: &Path, w: u32, h: u32, mask: &[u8]) -> Result<()> {
    let mut img: ImageBuffer<Rgba<u8>, Vec<u8>> = ImageBuffer::new(w, h);
    for y in 0..h {
        for x in 0..w {
            let idx = (y * w + x) as usize;
            let a = if mask[idx] != 0 { 255u8 } else { 0u8 };
            img.put_pixel(x, y, Rgba([255, 255, 255, a]));
        }
    }
    img.save(path)
        .with_context(|| format!("save png: {}", path.display()))?;
    Ok(())
}

fn main() -> Result<()> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        eprintln!("Usage: smart_trapper_b1 <JOB_FOLDER> [trapPx]");
        eprintln!(r#"Example: smart_trapper_b1 "C:\temp\byrne_job" 5"#);
        std::process::exit(2);
    }
    let job_folder = PathBuf::from(&args[1]);
    let trap_px: i32 = if args.len() >= 3 { args[2].parse().unwrap_or(5) } else { 5 };

    let job_path = job_folder.join("job.json");
    let job_txt = fs::read_to_string(&job_path)
        .with_context(|| format!("read job.json: {}", job_path.display()))?;
    let job: JobFile = serde_json::from_str(&job_txt)
        .with_context(|| "parse job.json (must be strict JSON)")?;

    // Map layer name -> file meta
    let mut file_map: HashMap<String, FileMeta> = HashMap::new();
    for f in &job.files {
        file_map.insert(f.name.clone(), f.clone());
    }

    // Load KEY mask if present
    let mut key_mask: Option<Vec<u8>> = None;
    for f in &job.files {
        if f.kind == "KEY" {
            let p = job_folder.join(&f.png);
            let (w, h, rgba) = read_mask_rgba(&p)?;
            if w != job.widthPx || h != job.heightPx {
                anyhow::bail!("KEY mask size mismatch ({}x{} vs {}x{})", w, h, job.widthPx, job.heightPx);
            }
            key_mask = Some(alpha_to_bit(w, h, &rgba));
        }
    }

    let traps_dir = job_folder.join("traps");
    if !traps_dir.exists() {
        fs::create_dir_all(&traps_dir)?;
    }

    let color_names: Vec<String> = job.colors.iter().map(|c| c.name.clone()).collect();
    let mut out = TrapsOut { traps: vec![] };

    for (ai, a_name) in color_names.iter().enumerate() {
        let a_file = file_map.get(a_name).context("missing A file meta")?;
        let a_path = job_folder.join(&a_file.png);
        let (w, h, rgba_a) = read_mask_rgba(&a_path)?;
        if w != job.widthPx || h != job.heightPx {
            anyhow::bail!("A mask size mismatch for {}", a_name);
        }
        let a = alpha_to_bit(w, h, &rgba_a);

        let a_is_multiply = a_file.blendMode.contains("MULTIPLY");
        let da = dilate_square(&a, w, h, trap_px);

        for bi in (ai + 1)..color_names.len() {
            let b_name = &color_names[bi];
            let b_file = file_map.get(b_name).context("missing B file meta")?;
            let b_path = job_folder.join(&b_file.png);
            let (wb, hb, rgba_b) = read_mask_rgba(&b_path)?;
            if wb != job.widthPx || hb != job.heightPx {
                anyhow::bail!("B mask size mismatch for {}", b_name);
            }
            let b = alpha_to_bit(w, h, &rgba_b);

            // Trap(A over B) = (dilate(A) & B) & !A
            let cand = and(&da, &b);
            let mut trap = and_not(&cand, &a);

            // Multiply-source guard: trap &= KEY if available
            if a_is_multiply {
                if let Some(k) = &key_mask {
                    trap = and(&trap, k);
                }
            }

            if !trap.iter().any(|&v| v != 0) {
                continue;
            }

            let out_name = format!(
                "TRAP__{}_over_{}.png",
                sanitize(a_name),
                sanitize(b_name)
            );
            let out_rel = format!("traps/{}", out_name);
            let out_path = traps_dir.join(&out_name);
            write_trap_png(&out_path, w, h, &trap)?;

            out.traps.push(TrapSpec {
                source: a_name.clone(),
                target: b_name.clone(),
                png: out_rel,
            });
        }

        // Optional: trap to KEY
        if let Some(k) = &key_mask {
            let cand = and(&da, k);
            let mut trap = and_not(&cand, &a);
            if a_is_multiply {
                trap = and(&trap, k);
            }
            if trap.iter().any(|&v| v != 0) {
                let out_name = format!("TRAP__{}_over_KEY.png", sanitize(a_name));
                let out_rel = format!("traps/{}", out_name);
                let out_path = traps_dir.join(&out_name);
                write_trap_png(&out_path, w, h, &trap)?;
                out.traps.push(TrapSpec {
                    source: a_name.clone(),
                    target: "KEY".to_string(),
                    png: out_rel,
                });
            }
        }
    }

    let traps_json = serde_json::to_string_pretty(&out)?;
    fs::write(job_folder.join("traps.json"), traps_json)?;

    println!("Done. Wrote traps.json + traps/*.png");
    Ok(())
}
